/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab17;

import java.util.List;

/**
 *
 * @author 2291195
 */
public class LibraryController {
    LibraryModel model = LibraryModel.getInstance();
    
    public List<Book> getBooks() {
        return model.getBooks();
    }
    
    public void addBook(Book book) {
        model.addBook(book);
    }
}
