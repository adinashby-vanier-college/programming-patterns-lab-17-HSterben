/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.lab17;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

/**
 *
 * @author 2291195
 */
public class LibraryModel extends Observable {

    private static LibraryModel library = null;
    private List<Book> books;
    private static final String JDBC_URL = "jdbc:sqlite:path_to_your_database_file.db";

    public LibraryModel() {
        this.books = new ArrayList<>();
        DatabaseInitializer.initializeDatabase();
    }

    public static LibraryModel getInstance() {
        if (library == null) {
            library = new LibraryModel();
        }
        return library;
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    public void addBook(Book book) {
        // Insert book into the database
        String sql = "INSERT INTO books(title, author) VALUES(?,?)";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // Notify observers about the new book
        setChanged();
        notifyObservers(book);
    }

    public List<Book> getBooks() {
        String sql = "SELECT id, title, author FROM books";
        try (Connection conn = this.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {

            // Clear the current books and repopulate with database entries
            books.clear();
            while (rs.next()) {
                Book book = new Book(
                        rs.getString("title"),
                        rs.getString("author"));
                books.add(book);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return books;
    }

    public void clearBooks() {
        String sql = "DELETE FROM books";

        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Execute the delete statement
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
